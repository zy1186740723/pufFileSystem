const app = getApp()
var list = app.globalData.userList

Page({

  /**
   * 页面的初始数据
   */
  data: {
    message: 'hahha'

  },

  /**
   * 生命周期函数--监听页面加载
   */
  onLoad: function (params) {
    this.setData({ your_value: getApp().globalData.userList }),
      this.setData({ your_fileName: getApp().globalData.fileName }),
      this.setData({ fileIdList: getApp().globalData.fileIdList })
  },
  //业务逻辑，点击微信图片下载并且预览
  doDownLoadFile: function (e) {
    console.info("点击了下载与预览文件");
    console.info(e.currentTarget.id);

    app.globalData.fileName = e.currentTarget.id;
    wx.setStorageSync("textInput", e.currentTarget.dataset.name);
    wx.setStorageSync("timestamp", e.currentTarget.id);
    console.info(wx.getStorageSync("fileId"));
    wx.redirectTo({
      url: '/pages/service/service12/service12?textInput='+wx.getStorageSync("textInput")
      +"&timestamp="+e.currentTarget.id
        
    })
  },
  doreturn: function () {
    wx.redirectTo({
      url: '/pages/service/service1',
    })
  },


  /**
   * 生命周期函数--监听页面卸载
   */
  onUnload: function () {

  },

  /**
   * 页面相关事件处理函数--监听用户下拉动作
   */
  onPullDownRefresh: function () {

  },

  /**
   * 页面上拉触底事件的处理函数
   */
  onReachBottom: function () {

  },

  /**
   * 用户点击右上角分享
   */
  onShareAppMessage: function () {

  }
})