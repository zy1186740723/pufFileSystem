// 阅读文字内容的申请
const app = getApp()

Page({

  /**
   * 页面的初始数据
   */
  data: {
    
  },

  /**
   * 生命周期函数--监听页面加载
   */
  onLoad: function (options) {
    console.info("===================进入了service10==================");
    wx.setStorageSync("userInput", options.userInput);
    wx.setStorageSync("textInput", options.timestamp);
    console.info(wx.getStorageSync("timestamp"))
    this.setData({ your_username: wx.getStorageSync("userInput") });

    
  },
  getFormID: function (e) {
    console.info(e.detail.formId);
    this.setData({
      formId: e.detail.formId
    })
    wx.request({
      url: app.globalData.baseUrl + '/submit2',
      header: {
        'content-type': 'application/x-www-form-urlencoded',
      },
      method: 'POST',
      data: {
        "Cookie": wx.getStorageSync("loginFlag"),
        "formId": e.detail.formId,
        //"username": wx.getStorageSync("userInput"),
        "timestamp": wx.getStorageSync("timestamp"),
      },
      success: function (res) {
        var error = res.data
        console.info(res)
        console.info(error)
        if (res.statusCode == 501) {
          console.log("进入重新登录");
          wx.navigateTo({
            url: '/pages/service/service7/service7?filename=' + wx.getStorageSync("tempfile"),
          })
        }
        else {
          console.info("提交审核成功");
          wx.redirectTo({
            url: '../service1',
          })
        }

      },
    })
  },
  return: function () {
    wx.redirectTo({
      url: '/pages/service/service1',
    })
  },

  /**
   * 生命周期函数--监听页面初次渲染完成
   */
  onReady: function () {
    
  },

  /**
   * 生命周期函数--监听页面显示
   */
  onShow: function () {
    
  },

  /**
   * 生命周期函数--监听页面隐藏
   */
  onHide: function () {
    
  },

  /**
   * 生命周期函数--监听页面卸载
   */
  onUnload: function () {
    
  },

  /**
   * 页面相关事件处理函数--监听用户下拉动作
   */
  onPullDownRefresh: function () {
    
  },

  /**
   * 页面上拉触底事件的处理函数
   */
  onReachBottom: function () {
    
  },

  /**
   * 用户点击右上角分享
   */
  onShareAppMessage: function () {
    
  }
})
