const app = getApp()
var filename = app.globalData.filename

Page({

  /**
   * 页面的初始数据
   */
  data: {
    
  },

  /**
   * 生命周期函数--监听页面加载
   */
  onLoad: function (options) {
    console.info("===================进入了service4==================");
    var res=wx.getStorageSync("loginFlag");
    
    //console.info(filename)
    this.setData({ your_fileName: getApp().globalData.fileName });
    console.info(options);
    wx.setStorageSync("tempfilename", options.filename)
    wx.setStorageSync("tempfileId", options.fileId)
    console.info(wx.getStorageSync("tempfilename"));
    console.info(wx.getStorageSync("tempfileId"));
    
  },

/**
 * 提交表单时触发的事件
 */
  getFormID: function (e) {
    console.info(e.detail.formId);
    this.setData({
      formId: e.detail.formId
    })
    wx.request({
      url: app.globalData.baseUrl+'/submit',
      header: {
        'content-type': 'application/x-www-form-urlencoded',
      },
      method: 'POST',
      data: {
        "Cookie": wx.getStorageSync("loginFlag"),
        "formId":e.detail.formId,
        "filename": wx.getStorageSync("tempfilename"),
        "fileId": wx.getStorageSync("tempfileId"),
      },
      success: function(res){
        var error = res.data
        console.info(res)
        console.info(error)
        if (error.error == 0) {
          console.log("进入重新登录");
          wx.navigateTo({
            url: '/pages/service/service7/service7?filename='+wx.getStorageSync("tempfile"),
          })
        }
        else {
          console.info("提交审核成功");
          wx.redirectTo({
            url: '../service1',
          })}
        
      },
    })
  },
  return: function(){
    wx.redirectTo({
      url: '/pages/service/service1',
    })
  },

  /**
   * 生命周期函数--监听页面初次渲染完成
   */
  onReady: function () {
    
  },

  /**
   * 生命周期函数--监听页面显示
   */
  onShow: function () {
    
  },

  /**
   * 生命周期函数--监听页面隐藏
   */
  onHide: function () {
    
  },

  /**
   * 生命周期函数--监听页面卸载
   */
  onUnload: function () {
    
  },

  /**
   * 页面相关事件处理函数--监听用户下拉动作
   */
  onPullDownRefresh: function () {
    
  },

  /**
   * 页面上拉触底事件的处理函数
   */
  onReachBottom: function () {
    
  },

  /**
   * 用户点击右上角分享
   */
  onShareAppMessage: function () {
    
  }
})