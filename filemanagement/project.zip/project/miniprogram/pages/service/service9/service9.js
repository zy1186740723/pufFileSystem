const app = getApp()


Page({

  /**
   * 页面的初始数据
   */
  data: {
    
  },

  /**
   * 生命周期函数--监听页面加载
   */
  onLoad: function (options) {
    //产生随机数，用来表示这次text的生成
    var timestamp = Date.parse(new Date());
    timestamp = timestamp / 1000;
    wx.setStorageSync("timestamp", timestamp)
    console.log("当前时间戳为：" + timestamp);
   
  },
  /**
   * 生命周期函数--监听页面初次渲染完成
   */
  onReady: function () {
    
  },

doUserInput: function(e){
  console.info("输入:"+e.detail.value);
  var userInput=e.detail.value
  wx.setStorageSync("userInput", userInput)
  console.info(wx.getStorageSync("userInput"))
},
  doTextInput: function (e) {
    console.info("输入:" + e.detail.value);
    var textInput = e.detail.value
    wx.setStorageSync("textInput", textInput)
  },
  return: function () {
    wx.redirectTo({
      url: '/pages/service/service1',
    })
  },
  //查询text列表
  doFindTextList: function () {
    wx.request({
      url: app.globalData.baseUrl + '/findTextList',
      header: {
        'content-type': 'application/x-www-form-urlencoded',
      },
      method: 'POST',
      data: {
        "Cookie": wx.getStorageSync("loginFlag"),
      },
      success: function (res) {
        console.info(res)
        var error = res.data
        console.info(error)
        if (res.statusCode == 501) {
          console.log("进入重新登录");
          wx.redirectTo({
            url: '../index/index',
          })
        }
        else {
          var app = getApp();
          console.info(res)
          console.info(res.data.filename)
          app.globalData.userList = res.data;
          app.globalData.fileIdList = res.data.fileIdList;
          wx.redirectTo({
            url: '/pages/service/service11/service11',
          })
        }

      }

    })
  },
  /**
   * 生命周期函数--监听页面显示
   */
  onShow: function () {
    
  },

  /**
   * 生命周期函数--监听页面隐藏
   */
  onHide: function () {
    
  },

  /**
   * 生命周期函数--监听页面卸载
   */
  onUnload: function () {
    
  },

  /**
   * 页面相关事件处理函数--监听用户下拉动作
   */
  onPullDownRefresh: function () {
    
  },

  /**
   * 页面上拉触底事件的处理函数
   */
  onReachBottom: function () {
    
  },

  /**
   * 用户点击右上角分享
   */
  onShareAppMessage: function (res) {
    console.info("输出结果:" + res)
    if (res.from === 'button') {
      wx.request({
        url: app.globalData.baseUrl + '/textSubmit',
        header: {
          'content-type': 'application/x-www-form-urlencoded',
        },
        method: 'POST',
        data: {
          "Cookie": wx.getStorageSync("loginFlag"),
          "textInput": wx.getStorageSync("textInput"),
          "timestamp": wx.getStorageSync("timestamp"),
        },
        success :function(){
          console.info("成功上传text")
        }
      })
      // 来自页面内转发按钮
      console.log(res.target)
      console.log("用户是" + wx.getStorageSync("userInput")
        + "内容是:" + wx.getStorageSync("textInput"))
    }
    return {
      title: "请用户："+wx.getStorageSync("userInput")+"查看消息",
      path: "/pages/service/service10/service10?userInput="+wx.getStorageSync("userInput")+
        "&timestamp:" + wx.getStorageSync("timestamp"),
      success: function (res) { 
        console.info("消息共享成功：用户是" + wx.getStorageSync("userInput")
         + "内容是:" + wx.getStorageSync("textInput"))
      }
    }
  }
})