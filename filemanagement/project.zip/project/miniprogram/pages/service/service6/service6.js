const app = getApp()
var username = app.globalData.registerList

Page({

  /**
   * 页面的初始数据
   */
  data: {
    
  },

  /**
   * 生命周期函数--监听页面加载
   */
  onLoad: function (options) {
    this.setData({ your_list: getApp().globalData.registerList })
  },

/**
 * 进行授权
 */
  doAuthorization: function(e){
    console.info(wx.getStorageSync("filename"))
    console.info("消息"+e.currentTarget.dataset.name)
    console.info("id" + e.currentTarget.id)
    wx.getStorageSync("loginFlag"),
    //var authoNameJson=params.detail.rawData;
    // var json1 = JSON.parse(authoNameJson);
    // var authoName = json1["nickName"]
    // console.info("姓名"+app.globalData.registerList)
    // console.info(authoName)
    wx.request({
      url: app.globalData.baseUrl+'/sendTemplate',
      header: {
        'content-type': 'application/x-www-form-urlencoded',
      },
      method: 'POST',
      data: {
        "Cookie": wx.getStorageSync("loginFlag"),
        "filename": wx.getStorageSync("filename"),
        "userName": e.currentTarget.dataset.name,
      },
      success: function(res){
        var error = res.data
        console.info(res)
        if (error.error == 0) {
          console.log("进入重新登录");
          wx.redirectTo({
            url: '/pages/index/index',
          })

        }
        else { console.info("推送成功")}
        
      },
    })
  },
  doreturn: function () {
    wx.redirectTo({
      url: '/pages/service/service1',
    })
  },

  /**
   * 生命周期函数--监听页面初次渲染完成
   */
  onReady: function () {
    
  },

  /**
   * 生命周期函数--监听页面显示
   */
  onShow: function () {
    
  },

  /**
   * 生命周期函数--监听页面隐藏
   */
  onHide: function () {
    
  },

  /**
   * 生命周期函数--监听页面卸载
   */
  onUnload: function () {
    
  },

  /**
   * 页面相关事件处理函数--监听用户下拉动作
   */
  onPullDownRefresh: function () {
    
  },

  /**
   * 页面上拉触底事件的处理函数
   */
  onReachBottom: function () {
    
  },

  /**
   * 用户点击右上角分享
   */
  onShareAppMessage: function () {
    
  }
})