// pages/service/service11/service12.js
const app = getApp()
var registerList = app.globalData.registerList
Page({

  /**
   * 页面的初始数据
   */
  data: {

  },

  /**
   * 生命周期函数--监听页面加载
   */
  onLoad: function (options) {
    console.info("携带的参数："+options.textInput)
    wx.setStorageSync("timestamp", options.timestamp)
  },
  doSupervision: function () {
    wx.request({
      url: app.globalData.baseUrl + '/supervision2',
      header: {
        'content-type': 'application/x-www-form-urlencoded',
      },
      method: 'POST',
      data: {
        "Cookie": wx.getStorageSync("loginFlag"),
        "textInput": wx.getStorageSync("textInput")
      },
      success: function (res) {
        var error = res.data
        console.info(res)
        if (res.statusCoder == 501) {
          console.log("进入重新登录");
          wx.redirectTo({
            url: '/pages/index/index',
          })

        }
        else if (res.statusCode == 500) {
          console.info("审核异常")
          wx.redirectTo({
            url: '/pages/service/service1',
          })
        }
        else {
          console.info(res);
          console.info("提交审核成功");
          app.globalData.registerList = res.data;
          console.info(registerList)
          wx.redirectTo({
            url: '/pages/service/service12/service12-2?timestamp='+wx.getStorageSync("timestamp"),
          })
        }
      }
    })
  },

  /**
   * 生命周期函数--监听页面初次渲染完成
   */
  onReady: function () {

  },

  /**
   * 生命周期函数--监听页面显示
   */
  onShow: function () {

  },

  /**
   * 生命周期函数--监听页面隐藏
   */
  onHide: function () {

  },

  /**
   * 生命周期函数--监听页面卸载
   */
  onUnload: function () {

  },

  /**
   * 页面相关事件处理函数--监听用户下拉动作
   */
  onPullDownRefresh: function () {

  },

  /**
   * 页面上拉触底事件的处理函数
   */
  onReachBottom: function () {

  },

  /**
   * 用户点击右上角分享
   */
  onShareAppMessage: function () {

  }
})