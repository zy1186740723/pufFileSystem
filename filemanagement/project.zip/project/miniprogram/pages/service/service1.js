const app = getApp()

Page({

  /**
   * 页面的初始数据
   */
  data: {
    
  },

  /**页面加载时的逻辑
   * 生命周期函数--监听页面加载
   */
  onLoad: function (params) {
  },
  doUpload: function(){
    wx.chooseImage({
      success(res) {
        const tempFilePaths = res.tempFilePaths
        console.info(tempFilePaths)
        wx.uploadFile({
          url: 'http://119.23.11.21:8888//uploadFile', //仅为示例，非真实的接口地址
          filePath: tempFilePaths[0],
          name: 'file',
          header: {"Content-Type": "multipart/form-data",
            "Cookie": wx.getStorageSync("loginFlag")
          },
          success: function(res) {
           console,info(res.statusCode)
            if (res.statusCode===500){
              console.log("进入重新登录");
             wx.redirectTo({
               url: '../index/index',
             })
            }
            else{
              console.info("上传成功")
            }
            //do something
          }
        })
      }
    })
   
  },

  //导入微信聊天文件
  doUploadWxFile: function () {
    wx.chooseMessageFile({
      count: 10,
      type: 'all',
      success(res) {
        const tempFilePaths = res.tempFiles[0].path
        console.info(res.tempFiles[0].name)
        wx.uploadFile({
          url: app.globalData.baseUrl+"/uploadFile", //仅为示例，非真实的接口地址
          filePath: res.tempFiles[0].path,
          name: 'file',
          header: {
            "Content-Type": "multipart/form-data",
            "Cookie": wx.getStorageSync("loginFlag"),
          },
          formData: {
            'fileName': res.tempFiles[0].name
          },
          success: function (res) {
           console.info(res.statusCode)
            if (res.statusCode==501) {
              console.log("进入重新登录");
              wx.redirectTo({
                url: '../index/index',
              })
            }
            if(res.statusCode==200){
              console.info("上传成功")
            }
            //do something
          }
        })
      }
    })

  },
  
  doDownloadFileList: function () {
    wx.request({
      url: app.globalData.baseUrl+'/downloadFileList2',
      header: {
        'content-type': 'application/x-www-form-urlencoded',
      },
      method: 'POST',
      data:{
        "Cookie": wx.getStorageSync("loginFlag"),
      },
      success: function(res){
        console.info(res)
        var error=res.data
        console.info(error)
        if (res.statusCode == 501) {
          console.log("进入重新登录");
          wx.redirectTo({
            url: '../index/index',
          })
        }
        else{
          var app = getApp();
          console.info(res)
          console.info(res.data.filename)
          app.globalData.userList = res.data;
          app.globalData.fileIdList = res.data.fileIdList;
          wx.redirectTo({
            url: '../service/server2/server2',
          })
        }
        
      }
    
    })
  },
  doSendMessage: function(){
    wx.redirectTo({
      url: '/pages/service/service9/service9',
    })
  },
  /**PUFs加密上传 */
  doPUFs: function(){
    wx.chooseMessageFile({
      count: 10,
      type: 'all',
      success(res) {
        const tempFilePaths = res.tempFiles[0].path
        console.info(res.tempFiles[0].name)
        wx.uploadFile({
          url: app.globalData.baseUrl + "/uploadFilePufs", //仅为示例，非真实的接口地址
          filePath: res.tempFiles[0].path,
          name: 'file',
          header: {
            "Content-Type": "multipart/form-data",
            "Cookie": wx.getStorageSync("loginFlag"),
          },
          formData: {
            'fileName': res.tempFiles[0].name
          },
          success: function (res) {
            console.info(res.statusCode)
            if (res.statusCode == 501) {
              console.log("进入重新登录");
              wx.redirectTo({
                url: '../index/index',
              })
            }
            if (res.statusCode == 200) {
              console.info("上传成功")
            }
            //do something
          }
        })
      }
    })
  },
  /**
   * 生命周期函数--监听页面初次渲染完成
   */
  onReady: function () {
    
  },

  /**
   * 生命周期函数--监听页面显示
   */
  onShow: function () {
    
  },

  /**
   * 生命周期函数--监听页面隐藏
   */
  onHide: function () {
    
  },

  /**
   * 生命周期函数--监听页面卸载
   */
  onUnload: function () {
    
  },

  /**
   * 页面相关事件处理函数--监听用户下拉动作
   */
  onPullDownRefresh: function () {
    
  },

  /**
   * 页面上拉触底事件的处理函数
   */
  onReachBottom: function () {
    
  },

  /**
   * 用户点击右上角分享
   */
  onShareAppMessage: function () {
    
  }
})