const app = getApp()

Page({

  /**
   * 页面的初始数据
   */
  data: {
    isHide: false
  },

  /**
   * 生命周期函数--监听页面加载
   */
  onLoad: function (res) {
    console.info("开始重新登录")
    console.info("参数"+res)
    var that = this;
    // 查看是否授权
    wx.getSetting({
      success: function (rses) {
        if (res.authSetting['scope.userInfo']) {
          wx.getUserInfo({
            success: function (res) {
              // 用户已经授权过,不需要显示授权页面,所以不需要改变 isHide 的值
              // 根据自己的需求有其他操作再补充
              // 我这里实现的是在用户授权成功后，调用微信的 wx.login 接口，从而获取code
              wx.login({
                success: function (res) {
                  console.log(res, ">>")
                  if (res) {
                    wx.getUserInfo({
                      success: function (infoRes) {
                        console.log(infoRes, ">>");
                        wx.request({
                          url: app.globalData.baseUrl+'/wxLogin',
                          method: 'POST',
                          header: { 'content-type': 'application/x-www-form-urlencoded' },
                          data: {
                            code: res.code,
                            rawData: infoRes.rawData,
                            signature: infoRes.signature,//签名
                            encrypteData: infoRes.encryptedData,//用户敏感信息
                            iv: infoRes.iv//解密算法的向量
                          },
                          success: function (res) {
                            console.log("success");
                            console.log(res);
                            res = res.data;
                            if (res.result == 0) {
                              wx.setStorageSync("loginFlag", res.skey);
                              console.log("loginFlag:" + res.skey);
                              wx.redirectTo({
                                url: '/pages/service/service4/service4?filename='+wx.getStorageSync("tempfilename"),
                              })
                            }
                            else {
                              console.info("res.error");
                            }
                          }
                        })
                      },

                    });
                  }

                  else { }


                }
              })
            }
          });
        } else {
          // 用户没有授权
          // 改变 isHide 的值，显示授权页面
          that.setData({
            isHide: true
          });

        }
      },
    })
   
  },

  /**
   * 生命周期函数--监听页面初次渲染完成
   */
  onReady: function () {
    
  },

  /**
   * 生命周期函数--监听页面显示
   */
  onShow: function () {
    
  },

  /**
   * 生命周期函数--监听页面隐藏
   */
  onHide: function () {
    
  },

  /**
   * 生命周期函数--监听页面卸载
   */
  onUnload: function () {
    
  },

  /**
   * 页面相关事件处理函数--监听用户下拉动作
   */
  onPullDownRefresh: function () {
    
  },

  /**
   * 页面上拉触底事件的处理函数
   */
  onReachBottom: function () {
    
  },

  /**
   * 用户点击右上角分享
   */
  onShareAppMessage: function () {
    
  }
})