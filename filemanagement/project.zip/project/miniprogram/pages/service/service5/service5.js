const app = getApp()
var filename=app.globalData.filename
var registerList = app.globalData.registerList

Page({

  /**
   * 页面的初始数据
   */
  data: {
    
  },

  /**
   * 生命周期函数--监听页面加载
   */
  onLoad: function (options) {
    this.setData({ your_filename: wx.getStorageSync("filename") });

  },

  doSupervision: function(){
    wx.request({
      url: app.globalData.baseUrl+'/supervision',
      header: {
        'content-type': 'application/x-www-form-urlencoded',
      },
      method: 'POST',
      data: {
        "Cookie": wx.getStorageSync("loginFlag"),
        "filename": wx.getStorageSync("filename")
      },
      success: function (res) {
        var error = res.data
        console.info(res)
        if (error.error == 0) {
          console.log("进入重新登录");
          wx.redirectTo({
            url: '/pages/index/index',
          })
        
        }
        else if(res.statusCode==500){
          console.info("审核异常")
          wx.redirectTo({
            url: '/pages/service/service1',
          })
        }
        else {
          console.info(res);
          console.info("提交审核成功");
          app.globalData.registerList = res.data;
          console.info(registerList)
          wx.redirectTo({
            url: '../service6/service6',
          })
        }}
  })},

  /**清空申请信息 */
  clear: function(){
    wx.request({
      url: app.globalData.baseUrl + '/clear',
      header: {
        'content-type': 'application/x-www-form-urlencoded',
      },
      method: 'POST',
      data: {
        "Cookie": wx.getStorageSync("loginFlag"),
        "filename": wx.getStorageSync("filename")
      },
      success: function (res) {
        var error = res.data
        console.info(res)
        if (error.error == 0) {
          console.log("进入重新登录");
          wx.redirectTo({
            url: '/pages/index/index',
          })

        }
        else if (res.statusCode == 500) {
          console.info("审核异常")
          wx.redirectTo({
            url: '/pages/service/service1',
          })
        }
        else {
          console.info(res);
          console.info("提交审核成功");
          app.globalData.registerList = res.data;
          console.info(registerList)
          wx.redirectTo({
            url: '../service6/service6',
          })
        }
      }
    })
  },
  /**
   * 生命周期函数--监听页面初次渲染完成
   */
  onReady: function () {
    
  },

  /**
   * 生命周期函数--监听页面显示
   */
  onShow: function () {
    
  },

  /**
   * 生命周期函数--监听页面隐藏
   */
  onHide: function () {
    
  },

  /**
   * 生命周期函数--监听页面卸载
   */
  onUnload: function () {
    
  },

  /**
   * 页面相关事件处理函数--监听用户下拉动作
   */
  onPullDownRefresh: function () {
    
  },

  /**
   * 页面上拉触底事件的处理函数
   */
  onReachBottom: function () {
    
  },

  /**
   * 用户点击右上角分享
   */
  onShareAppMessage: function () {
    
  }
})