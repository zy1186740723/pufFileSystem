const app = getApp()
var list = app.globalData.userList



Page({

  /**
   * 页面的初始数据
   */
  data: {
   

  },

  /**
   * 生命周期函数--监听页面加载
   */
  onLoad: function (options) {
    this.setData({ your_fileName: wx.getStorageSync("filename") });
    wx.showShareMenu({
      withShareTicket: true
    })
    console.info("onload"+options)
   
  },

  onShow: function(params){
    
  },
  
 



  /**
   * 生命周期函数--监听页面卸载
   */
  onUnload: function () {

  },

//业务逻辑，点击微信图片下载并且预览
  downloadFile: function(e){
    wx.setStorageSync("sendFile", e.currentTarget.id )
    var downloadFileName = e.currentTarget.id;
    //wx.setStorageSync(key, data)
    console.info(downloadFileName);
    wx.downloadFile({
      url: app.globalData.baseUrl+"/downloadFile2?file_id="+downloadFileName,
      header: {
        "Cookie": wx.getStorageSync("loginFlag"),
      },
      data:{
        "Cookie": wx.getStorageSync("loginFlag"),
      },
    
      success: function(res){
          console.info(res)
          var filePath = res.tempFilePath;
          if(res.statusCode==200){
            wx.openDocument({
              filePath: filePath,
              fileType: "pdf",
              success: function (e) {
                console.info("文件打开成功")
              },
              fail(err) {
                console.info(err)
              }
            })
          }
          if(res.statusCode==501){
            wx.redirectTo({
              url: '/pages/index/index',
            })
          }
      },
      
    })
  },
  /**PUFs解密下载 */
  doPUFsDownload:function(e){
    wx.setStorageSync("sendFile", e.currentTarget.id)
    var downloadFileName = e.currentTarget.id;
    //wx.setStorageSync(key, data)
    console.info(downloadFileName);
    wx.downloadFile({
      url: app.globalData.baseUrl + "/downloadFilePUFs?file_id=" + downloadFileName,
      header: {
        "Cookie": wx.getStorageSync("loginFlag"),
      },
      data: {
        "Cookie": wx.getStorageSync("loginFlag"),
      },

      success: function (res) {
        console.info(res)
        var filePath = res.tempFilePath;
        if (res.statusCode == 200) {
          wx.openDocument({
            filePath: filePath,
            fileType: "pdf",
            success: function (e) {
              console.info("文件打开成功")
            },
            fail(err) {
              console.info(err)
            }
          })
        }
        if (res.statusCode == 501) {
          wx.redirectTo({
            url: '/pages/index/index',
          })
        }
      },

    })
  },

/**
 * 查看用户的申请下载文件的信息
 */
  supervision: function(){
    wx.redirectTo({
      url: '../service5/service5',
    })

  },
  doreturn: function(){
    wx.redirectTo({
      url: '../service1',
    })
  },
  /**删除文件
   * 
   */

  delete: function(){
    console.info("删除文件名称"+wx.getStorageSync("filename"))
    wx.request({
      url: app.globalData.baseUrl + "/delete",
      header: {
      },
      data: {
        "Cookie": wx.getStorageSync("loginFlag"),
        "file_id":wx.getStorageSync("filename"),
      },
      success: function(){
        wx.redirectTo({
          url: '/pages/service/service1',
        })
      }
    })
  },
  /**
   * 页面相关事件处理函数--监听用户下拉动作
   */
  onPullDownRefresh: function () {

  },

  /**
   * 页面上拉触底事件的处理函数
   */
  onReachBottom: function () {

  },

  /**
   * 用户点击右上角分享
   */
  onShareAppMessage: function (res) {
    wx.showShareMenu({
      withShareTicket: true
    }) 
    console.info("开始信息分享");
    console.info()
    return {
      title: '分享测试', // 转发后 所显示的title
      path: '/pages/service/service4/service4?filename='+wx.getStorageSync("filename")+"&fileId="+wx.getStorageSync("fileId"), // 相对的路径
      success: function(res){    // 成功后要做的事情
        console.info("共享成功");

        console.log(res.shareTickets[0])
        wx.getShareInfo({
          shareTicket: res.shareTickets[0],
          success: function(res){
          var encrytedData=res.encryptedData;
          var iv=res.iv;
          console.log('成功', res)
          console.info(res);
          },
          fail: function (res) { console.log("失败"+res) },
          complete: function (res) { console.log(res) }
        })
      },
      fail: function (res) {
        // 分享失败
        console.info("共享失败");
        console.log(res)
      }
    }


  }

})