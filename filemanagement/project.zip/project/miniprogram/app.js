//app.js
App({
  userInfo: null,
  setGlobalUserInfo: function(user){
    wx.setStorageSync("userInfo", user)
  },

  getGlobalUserInfo: function(user){
    return wx.getStorageSync("userInfo")
  },
  onLaunch: function (options) {
    wx.showShareMenu({
      withShareTicket: true
    })
    
    if (!wx.cloud) {
      console.error('请使用 2.2.3 或以上的基础库以使用云能力')
    } else {
      wx.cloud.init({
        // env 参数说明：
        //   env 参数决定接下来小程序发起的云开发调用（wx.cloud.xxx）会默认请求到哪个云环境的资源
        //   此处请填入环境 ID, 环境 ID 可打开云控制台查看
        //   如不填则使用默认环境（第一个创建的环境）
        // env: 'my-env-id',
        traceUser: true,
      })}

      let that = this
    console.log(options.filename)
    wx.setStorageSync("tempFileName", options.filename)
      console.log(options)
      //中间省略其他代码
      if (options.scene == 1044) {
        console.info("用户已经根据依据共享卡片进入")
        wx.getShareInfo({
          shareTicket: options.shareTicket,
          success: function(res){
            console.info("成功获得敏感信息");
            console.info(res);
            var encryptedData = res.encryptedData;
            var iv=res.iv;
            // wx.request({
            //   url: 'http://localhost:8080/shareInfo',
            //   method: 'POST',
            //   header: { 'content-type': 'application/x-www-form-urlencoded',
            //     "Cookie": "948297d1-d38e-4f22-9f1a-9bccf7737767"
            //    },
            //   data: {
            //     encrypteData: encryptedData,//用户敏感信息
            //     iv: iv//解密算法的向量
            //   },
            //   success: function(res){
            //     console.info(res);
            //     console.info(res.data);
               
            //   }
            // })
            console.info("用户点击进来");
          }
          
        })
        }
        //这里写入相关业务代码
    console.info("没有进入共享点击的业务逻辑");
    
    
    

    this.globalData = {
      userList: null,
      fileIdList:null,
      textList:null,
      fileId:null,
      fileName: null,
      fileType: "pdf", 
      username: null,
      cookie:null,
      registerList:null,
      baseUrl:"http://119.23.11.21:8888",
    }
  },
  onShow: function(){

  },


})
